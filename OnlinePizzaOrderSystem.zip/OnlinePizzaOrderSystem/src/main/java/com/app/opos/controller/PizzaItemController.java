package com.app.opos.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.app.opos.model.PizzaItemModel;
import com.app.opos.model.PizzaPricingModel;
import com.app.opos.pojos.PizzaItem;
import com.app.opos.pojos.PizzaPricing;
import com.app.opos.service.PizzaItemService;

@RestController
@RequestMapping(value = "/item")
public class PizzaItemController {

	@Autowired
	private PizzaItemService itemService;

	@GetMapping(value = "/getTypes")
	public ResponseEntity<List<String>> getPizzaTypes() {
		List<String> types = itemService.getPizzaTypes();
		return new ResponseEntity<List<String>>(types, HttpStatus.OK);
	}

	@GetMapping(value = "/getCategory/{type}")
	public ResponseEntity<List<String>> getPizzaCategories(@PathVariable String type) {
		List<String> categories = itemService.getPizzaCategory(type);
		return new ResponseEntity<List<String>>(categories, HttpStatus.OK);
	}

	@GetMapping(value = "/getPizza")
	public ResponseEntity<List<PizzaItemModel>> getPizzaItem(@RequestParam String type, @RequestParam String category) {
		PizzaItemModel model = null;
		List<PizzaItemModel> itemModels = new ArrayList<PizzaItemModel>();
		List<PizzaItem> items = itemService.gitPizzaItems(type, category);

		for (PizzaItem item : items) {
			model = new PizzaItemModel();
			model.setCategory(item.getCategory());
			model.setDescription(item.getDescription());
			model.setName(item.getName());
			model.setType(item.getType());
			model.setId(item.getId());
			itemModels.add(model);
		}
		return new ResponseEntity<List<PizzaItemModel>>(itemModels, HttpStatus.FOUND);
	}

	@GetMapping(value = "/getPizzaDtls")
	public ResponseEntity<PizzaItemModel> getPizzaDetails(@RequestParam Integer id) {
		PizzaItemModel itemModel = new PizzaItemModel();
		List<PizzaPricingModel> pricingModels = new ArrayList<PizzaPricingModel>();
		PizzaItem item = itemService.getPizzaDetails(id).get();
		itemModel.setId(item.getId());
		itemModel.setName(item.getName());
		itemModel.setType(item.getType());
		itemModel.setCategory(item.getCategory());
		itemModel.setDescription(item.getDescription());
		List<PizzaPricing> pricings = item.getPricings();
		for (PizzaPricing price : pricings) {
			PizzaPricingModel priceModel = new PizzaPricingModel();
			priceModel.setId(price.getId());
			priceModel.setSize(price.getSize());
			priceModel.setPrice(price.getPrice());
			priceModel.setPizzaId(price.getItem().getId());
			pricingModels.add(priceModel);
		}
		itemModel.setpList(pricingModels);
		return new ResponseEntity<PizzaItemModel>(itemModel, HttpStatus.OK);
	}
}
