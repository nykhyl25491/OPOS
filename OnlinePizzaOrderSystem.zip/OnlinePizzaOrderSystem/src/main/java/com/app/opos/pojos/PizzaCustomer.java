package com.app.opos.pojos;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name="pizza_customers")
@XmlRootElement
public class PizzaCustomer 
{
	private Integer id;
	private String name;
	private String email;
	private String mobile;
	private String password;
	private String address;
	private List<PizzaOrder> orders;
	private PizzaCart cart;
	
	public PizzaCustomer() {
		// TODO Auto-generated constructor stub
	}

	public PizzaCustomer(String name, String email, String mobile, String password, String address) {
		super();
		this.name = name;
		this.email = email;
		this.mobile = mobile;
		this.password = password;
		this.address = address;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID")
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Column(name="Name")
	public String getName() {
		return name;
	}

	

	public void setName(String name) {
		this.name = name;
	}

	@Column(name="Email")
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Column(name="Mobile")
	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	@Column(name="Password")
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Column(name="Address")
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "PizzaCustomer [ID=" + id + ", name=" + name + ", email=" + email + ", mobile=" + mobile + ", password="
				+ password + ", address=" + address + "]";
	}

	@OneToMany(mappedBy = "customer",cascade = CascadeType.ALL,fetch = FetchType.LAZY)
	public List<PizzaOrder> getOrders() {
		return orders;
	}

	public void setOrders(List<PizzaOrder> orders) {
		this.orders = orders;
	}

	@OneToOne(cascade = CascadeType.ALL,fetch = FetchType.LAZY,mappedBy = "customer")
	public PizzaCart getCart() {
		return cart;
	}

	public void setCart(PizzaCart cart) {
		this.cart = cart;
	}
	
	
}
