package com.app.opos.pojos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "pizza_pricing")
public class PizzaPricing {
	private Integer id;
	private String size;
	private double price;
	private PizzaItem item;

	public PizzaPricing() {
	}

	public PizzaPricing(String size, double price) {
		super();
		this.size = size;
		this.price = price;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Column(name = "SIZES")
	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	@Column(name = "Price")
	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@ManyToOne
	@JoinColumn(name = "ITEMID")
	public PizzaItem getItem() {
		return item;
	}

	public void setItem(PizzaItem item) {
		this.item = item;
	}

	@Override
	public String toString() {
		return "PizzaPricing [id=" + id + ", size=" + size + ", price=" + price + "]";
	}
}
