package com.app.opos.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.opos.pojos.PizzaCart;
import com.app.opos.repository.CartRepository;

@Service
@Transactional
public class CartServiceImpl implements CartService
{
	@Autowired
	private CartRepository cartRepo;
	@Override
	public void addToCart(PizzaCart cart) {
		cartRepo.save(cart);
		
	}
	@Override
	public List<PizzaCart> showCarts(Integer cId) {
		return cartRepo.showCarts(cId);
	}

}
