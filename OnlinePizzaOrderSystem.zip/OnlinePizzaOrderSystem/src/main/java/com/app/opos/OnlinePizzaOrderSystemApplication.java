package com.app.opos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlinePizzaOrderSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlinePizzaOrderSystemApplication.class, args);
	}

}
