package com.app.opos.repository;

import org.springframework.data.repository.CrudRepository;

import com.app.opos.pojos.PizzaPricing;

public interface PizzaPricingRepository extends CrudRepository<PizzaPricing, Integer> 
{
	
}
