package com.app.opos.service;

import com.app.opos.pojos.PizzaCustomer;

public interface CustomerService {
	public PizzaCustomer validateCustomer(PizzaCustomer customer);

	public Iterable<PizzaCustomer> getAllCustomer();

	public void registerCustomer(PizzaCustomer customer);
}
