package com.app.opos.pojos;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="pizza_orders")
public class PizzaOrder 
{
	private Integer id;
	private Date orderTime;
	private String status;
	private PizzaCustomer customer;
	
	public PizzaOrder() {
		// TODO Auto-generated constructor stub
	}

	public PizzaOrder(Date orderTime, String status) {
		super();
		this.setOrderTime(orderTime);
		this.status = status;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	

	@Column(name="status")
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@ManyToOne
	@JoinColumn(name="customer_id")
	public PizzaCustomer getCustomer() {
		return customer;
	}

	public void setCustomer(PizzaCustomer customer) {
		this.customer = customer;
	}
	
	@Column(name="order_time")
	@Temporal(TemporalType.DATE)
	public Date getOrderTime() {
		return orderTime;
	}

	public void setOrderTime(Date orderTime) {
		this.orderTime = orderTime;
	}
	
	
}
