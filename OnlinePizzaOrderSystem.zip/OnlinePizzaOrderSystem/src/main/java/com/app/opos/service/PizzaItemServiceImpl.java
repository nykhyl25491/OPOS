package com.app.opos.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.opos.pojos.PizzaItem;
import com.app.opos.repository.PizzaItemRepository;

@Service
@Transactional
public class PizzaItemServiceImpl implements PizzaItemService {
	@Autowired
	private PizzaItemRepository itemRepository;

	@Override
	public List<String> getPizzaTypes() {
		return itemRepository.findDistinctType();
	}

	@Override
	public List<String> getPizzaCategory(String type) {
		return itemRepository.findDistinctCategoryByType(type);
	}

	@Override
	public List<PizzaItem> gitPizzaItems(String type, String category) {
		return itemRepository.findByTypeAndCategory(type, category);
	}

	@Override
	public Optional<PizzaItem> getPizzaDetails(Integer id) {
		return itemRepository.findById(id);
	}
}
