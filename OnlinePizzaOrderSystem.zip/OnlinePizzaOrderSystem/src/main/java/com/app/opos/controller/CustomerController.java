package com.app.opos.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;

import com.app.opos.exception.CustomerNotFoundException;
import com.app.opos.exception.ExceptionModel;
import com.app.opos.pojos.CustomerDetailsHolder;
import com.app.opos.pojos.PizzaCustomer;
import com.app.opos.service.CustomerService;

@RestController
@RequestMapping(value = "/customer")
public class CustomerController {
	//private static final Logger LOGGER = LoggerFactory.getLogger(CustomerController.class);
	private static final Logger LOGGER = LogManager.getLogger(CustomerController.class);
	@Autowired
	private CustomerService custService;

	@GetMapping(value = "/getCustomers",produces ={MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
	public ResponseEntity<CustomerDetailsHolder> getAllCustomer() {
		CustomerDetailsHolder customers = new CustomerDetailsHolder();
		customers.setPizzaCustomers((List<PizzaCustomer>) custService.getAllCustomer());
		return new ResponseEntity<CustomerDetailsHolder>(customers,HttpStatus.OK);
	}

	/*
	 * @GetMapping(value = "/getCustomers") public List<PizzaCustomer>
	 * getAllCustomer() { List<PizzaCustomer> custList = (List<PizzaCustomer>)
	 * custService.getAllCustomer(); return custList; }
	 */
	@PostMapping(value = "/register")
	public ResponseEntity<HttpStatus> registerCustomer(@RequestBody PizzaCustomer customer)
	{
		custService.registerCustomer(customer);
		return new ResponseEntity<HttpStatus>(HttpStatus.CREATED);
	}
	
	@PostMapping(value = "/login",produces ={MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE},
			consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
	public PizzaCustomer customerLogin(@RequestBody PizzaCustomer customer,HttpSession hs)
	{
		PizzaCustomer validCustomer = custService.validateCustomer(customer);
		if (validCustomer == null)
		{
			LOGGER.info("-----Customer Not Found-----");
			throw new CustomerNotFoundException("Invalid Login Credentials");
		}
		else
		{
			hs.setAttribute("Valid_Cust", validCustomer);
			LOGGER.info("-----Customer Found-----");
			return validCustomer;
		}
	}

	@ExceptionHandler(CustomerNotFoundException.class)
	public ResponseEntity<ExceptionModel> customerNotFoundHandler(CustomerNotFoundException ex, WebRequest request) {
		LOGGER.info("-----Exceprion Occured-----"+ex);
		ExceptionModel model = new ExceptionModel(new Date(), ex.getMessage(), request.getDescription(false), "404");
		return new ResponseEntity<ExceptionModel>(model, HttpStatus.NOT_FOUND);
	}
}
