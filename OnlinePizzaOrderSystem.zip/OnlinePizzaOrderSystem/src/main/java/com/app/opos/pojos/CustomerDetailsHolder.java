package com.app.opos.pojos;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "CustomXMl")
public class CustomerDetailsHolder {


	private List<PizzaCustomer> pizzaCustomers;

	public List<PizzaCustomer> getPizzaCustomers() {
		return pizzaCustomers;
	}

	public void setPizzaCustomers(List<PizzaCustomer> pizzaCustomers) {
		this.pizzaCustomers = pizzaCustomers;
	}

	
	
	
}
