package com.app.opos.repository;

import org.springframework.data.repository.CrudRepository;

import com.app.opos.pojos.PizzaCustomer;

public interface CustomerRepository extends CrudRepository<PizzaCustomer, Integer> 
{
	public PizzaCustomer findByEmailAndPassword(String email,String password);
	
}
