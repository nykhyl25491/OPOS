package com.app.opos.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.app.opos.pojos.PizzaCart;

public interface CartRepository extends CrudRepository<PizzaCart, Integer> 
{
	@Query(value = "select * from pizza_cart where customer_id=:cId",nativeQuery = true)
	public List<PizzaCart> showCarts(Integer cId);
	
	//public List<PizzaCart> findAll(int cId);
}
