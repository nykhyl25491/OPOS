package com.app.opos.service;

import java.util.List;

import com.app.opos.pojos.PizzaCart;

public interface CartService 
{
	public void addToCart(PizzaCart cart);
	public List<PizzaCart> showCarts(Integer cId);
}
