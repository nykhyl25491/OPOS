package com.app.opos.pojos;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name = "pizza_items")
public class PizzaItem {
	private Integer id;
	private String name;
	private String type;
	private String category;
	private String description;
	private List<PizzaPricing> pricings;

	public PizzaItem() {
		// TODO Auto-generated constructor stub
	}

	public PizzaItem(String name, String type, String category, String description) {
		super();
		this.name = name;
		this.type = type;
		this.category = category;
		this.description = description;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Column(name = "Name")
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Column(name = "Type")
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Column(name = "Category")
	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	@Column(name = "Description")
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "item")
	public List<PizzaPricing> getPricings() {
		return pricings;
	}

	public void setPricings(List<PizzaPricing> pricings) {
		this.pricings = pricings;
	}

	@Override
	public String toString() {
		return "PizzaItem [id=" + id + ", name=" + name + ", type=" + type + ", category=" + category + ", description="
				+ description + "]";
	}

}
