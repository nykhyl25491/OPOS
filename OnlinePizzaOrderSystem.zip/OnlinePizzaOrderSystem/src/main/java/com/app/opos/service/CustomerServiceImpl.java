package com.app.opos.service;

import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.app.opos.pojos.PizzaCustomer;
import com.app.opos.repository.CustomerRepository;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService {
	@Autowired
	private CustomerRepository custRepository;

	@Override
	public PizzaCustomer validateCustomer(PizzaCustomer customer) {
		return custRepository.findByEmailAndPassword(customer.getEmail(), customer.getPassword());
	}

	@Override
	public Iterable<PizzaCustomer> getAllCustomer() {
		return custRepository.findAll();
	}

	@Override
	public void registerCustomer(PizzaCustomer customer) {
		custRepository.save(customer);
	}

}
