package com.app.opos.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.app.opos.pojos.PizzaItem;

public interface PizzaItemRepository extends CrudRepository<PizzaItem, Integer> {
	
	@Query("SELECT DISTINCT type FROM PizzaItem")
	public List<String> findDistinctType();

	@Query("SELECT DISTINCT category from PizzaItem where type=:type")
	public List<String> findDistinctCategoryByType(String type);

	public List<PizzaItem> findByTypeAndCategory(String type, String category);
}
