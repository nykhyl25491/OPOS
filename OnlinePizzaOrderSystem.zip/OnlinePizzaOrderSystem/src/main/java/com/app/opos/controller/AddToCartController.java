package com.app.opos.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.app.opos.pojos.PizzaCart;
import com.app.opos.pojos.PizzaCustomer;
import com.app.opos.pojos.PizzaPricing;
import com.app.opos.repository.PizzaPricingRepository;
import com.app.opos.service.CartService;

@RestController
@RequestMapping(value = "cart")
public class AddToCartController 
{
	@Autowired
	private CartService cartService;
	
	@Autowired
	private PizzaPricingRepository priceRepo;
	
	@PostMapping(value = "/addToCart")
	public ResponseEntity<HttpStatus> addToCart(@RequestParam int pId,@RequestBody PizzaCart cart,HttpSession hs)
	{
		PizzaPricing price = priceRepo.findById(pId).get();
		cart.setPrice(price);
		PizzaCustomer customer = (PizzaCustomer) hs.getAttribute("Valid_Cust");
		cart.setCustomer(customer);
		cartService.addToCart(cart);
		return new ResponseEntity<HttpStatus>(HttpStatus.CREATED);
	}

	@GetMapping(value = "/showCart/{cId}")
	public ResponseEntity<List<PizzaCart>> showCarts(@PathVariable Integer cId)
	{
		return new ResponseEntity<List<PizzaCart>>(cartService.showCarts(cId),HttpStatus.OK);
	}
}