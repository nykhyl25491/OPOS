package com.app.opos.model;

public class PizzaPricingModel 
{
	private Integer id;
	private String size;
	private double price;
	private int pizzaId;
	
	public PizzaPricingModel() {

	}

	

	public PizzaPricingModel(Integer id, String size, double price, int pizzaId) {
		super();
		this.id = id;
		this.size = size;
		this.price = price;
		this.pizzaId = pizzaId;
	}



	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
	public int getPizzaId() {
		return pizzaId;
	}



	public void setPizzaId(int pizzaId) {
		this.pizzaId = pizzaId;
	}



	@Override
	public String toString() {
		return "PizzaPricingModel [id=" + id + ", size=" + size + ", price=" + price + "]";
	}
	
}
