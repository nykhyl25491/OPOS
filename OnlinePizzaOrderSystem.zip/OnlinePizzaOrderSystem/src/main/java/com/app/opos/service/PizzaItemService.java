package com.app.opos.service;

import java.util.List;
import java.util.Optional;

import com.app.opos.pojos.PizzaItem;

public interface PizzaItemService {
	public List<String> getPizzaTypes();

	public List<String> getPizzaCategory(String type);

	public List<PizzaItem> gitPizzaItems(String type, String category);
	
	public Optional<PizzaItem> getPizzaDetails(Integer id);
}
