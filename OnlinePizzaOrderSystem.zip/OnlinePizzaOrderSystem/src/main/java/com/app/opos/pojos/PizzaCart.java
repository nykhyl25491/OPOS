package com.app.opos.pojos;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
@Table(name = "pizza_cart")
public class PizzaCart 
{
	private Integer cartId;
	private int quantity;
	private Date createdDate;
	private PizzaCustomer customer;
	private PizzaPricing price;
	
	public PizzaCart() {
		
	}

	public PizzaCart(int quantity, Date createdDate) {
		super();
		this.quantity = quantity;
		this.createdDate = createdDate;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="cart_id")
	public Integer getCartId() {
		return cartId;
	}

	public void setCartId(Integer cartId) {
		this.cartId = cartId;
	}

	@Column(name="quantity")
	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Temporal(TemporalType.DATE)
	@Column(name="created_date")
	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	@OneToOne
	@JoinColumn(name="customer_id")
	public PizzaCustomer getCustomer() {
		return customer;
	}

	public void setCustomer(PizzaCustomer customer) {
		this.customer = customer;
	}

	@OneToOne
	@JoinColumn(name="price_id")
	public PizzaPricing getPrice() {
		return price;
	}

	public void setPrice(PizzaPricing price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "PizzaCart [cartId=" + cartId + ", quantity=" + quantity + ", createdDate=" + createdDate + "]";
	}

	
	
}
